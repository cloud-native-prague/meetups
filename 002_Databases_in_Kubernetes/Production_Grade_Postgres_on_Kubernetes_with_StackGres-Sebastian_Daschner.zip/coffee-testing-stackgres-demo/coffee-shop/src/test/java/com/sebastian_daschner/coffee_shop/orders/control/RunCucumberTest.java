package com.sebastian_daschner.coffee_shop.orders.control;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions
public class RunCucumberTest {



}
