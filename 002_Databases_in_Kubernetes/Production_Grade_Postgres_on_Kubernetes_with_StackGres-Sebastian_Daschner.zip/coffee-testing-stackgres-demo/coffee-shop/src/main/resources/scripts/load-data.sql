--
-- insert data

INSERT INTO origins VALUES ('Ethiopia');
INSERT INTO origin_coffee_types VALUES ('Ethiopia', 'ESPRESSO');
INSERT INTO origin_coffee_types VALUES ('Ethiopia', 'LATTE');
INSERT INTO origin_coffee_types VALUES ('Ethiopia', 'POUR_OVER');

INSERT INTO origins VALUES ('Colombia');
INSERT INTO origin_coffee_types VALUES ('Colombia', 'ESPRESSO');
INSERT INTO origin_coffee_types VALUES ('Colombia', 'POUR_OVER');