// required so that the quarkus:dev process wouldn't fail
public class Dummy {

}